const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('needle', {
  pickFolder: () => ipcRenderer.invoke('pick-folder'),
  scan: (dir) => ipcRenderer.invoke('scan', dir)
});
