# NEEDLE X

Local-only music player. No ads, no login, no subscription, no analytics.
Dark AMOLED liquid-glass UI, purple / cyan / silver. A record spins and the needle drops when you play.

## Windows (.exe)
Requires Node.js 18+.
    cd windows
    npm install
    npm start          # run it
    npm run dist       # installer appears in windows/dist/NEEDLE X Setup 1.0.0.exe

## Android (.apk)
Requires Android Studio (Koala or newer) with JDK 17.
1. Open the `android` folder in Android Studio. It creates the Gradle wrapper and syncs.
2. Run on your phone (USB debugging) or choose Build > Build Bundle(s) / APK(s) > Build APK(s).
3. APK: android/app/build/outputs/apk/debug/app-debug.apk. Copy it to the phone and install.
Allow music access on first launch.

## Notes
- Windows: Add folder to pick music folders (scanned recursively; mp3, flac, wav, ogg, m4a, aac, opus). Space = play/pause, arrows = prev/next.
- Android: plays everything in your phone's music library. Playback stops when the app is closed (no background service yet).
