package com.needlex

import android.Manifest
import android.content.ContentUris
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

val Purple = Color(0xFF8B5CF6)
val Cyan = Color(0xFF22D3EE)
val Silver = Color(0xFFC7CCD6)
val Glass = Color(0x0FFFFFFF)
val Edge = Color(0x24FFFFFF)

data class Track(val id: Long, val title: String, val artist: String, val uri: Uri)

class MainActivity : ComponentActivity() {
    private var player: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NeedleApp() }
    }

    override fun onDestroy() {
        player?.release()
        super.onDestroy()
    }

    private fun loadTracks(): List<Track> {
        val out = mutableListOf<Track>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        contentResolver.query(
            collection, proj, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                out += Track(id, c.getString(1) ?: "Unknown", c.getString(2) ?: "", ContentUris.withAppendedId(collection, id))
            }
        }
        return out
    }

    @Composable
    fun NeedleApp() {
        MaterialTheme(colorScheme = darkColorScheme(background = Color.Black, surface = Color.Black, primary = Purple)) {
            var tracks by remember { mutableStateOf(listOf<Track>()) }
            var cur by remember { mutableIntStateOf(-1) }
            var playing by remember { mutableStateOf(false) }
            var progress by remember { mutableFloatStateOf(0f) }
            var query by remember { mutableStateOf("") }
            var shuffle by remember { mutableStateOf(false) }
            var denied by remember { mutableStateOf(false) }

            fun play(i: Int) {
                if (i !in tracks.indices) return
                player?.release()
                cur = i
                player = MediaPlayer.create(this@MainActivity, tracks[i].uri)?.apply {
                    setOnCompletionListener {
                        val next = if (shuffle) tracks.indices.random() else (cur + 1) % tracks.size
                        play(next)
                    }
                    start()
                }
                playing = player != null
            }
            fun step(d: Int) {
                if (tracks.isEmpty()) return
                play(if (shuffle) tracks.indices.random() else (cur + d + tracks.size) % tracks.size)
            }

            val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
            else Manifest.permission.READ_EXTERNAL_STORAGE
            val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
                if (ok) tracks = loadTracks() else denied = true
            }
            LaunchedEffect(Unit) { launcher.launch(perm) }
            LaunchedEffect(playing, cur) {
                while (playing) {
                    val p = player
                    if (p != null && p.duration > 0) progress = p.currentPosition / p.duration.toFloat()
                    delay(300)
                }
            }

            val spin = rememberInfiniteTransition(label = "spin")
            val angle by spin.animateFloat(0f, 360f, infiniteRepeatable(tween(4000, easing = LinearEasing)), label = "a")
            val armAngle by animateFloatAsState(if (playing) 22f else -8f, tween(600), label = "arm")

            Column(
                Modifier.fillMaxSize()
                    .background(Brush.radialGradient(listOf(Color(0x40_8B5CF6), Color.Black), Offset(200f, 0f), 1200f))
                    .statusBarsPadding().navigationBarsPadding().padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("NEEDLE X", color = Color.White, fontSize = 20.sp, letterSpacing = 6.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Light)
                Spacer(Modifier.height(14.dp))
                Box(Modifier.size(210.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize().rotate(if (playing) angle else 0f)) {
                        val r = size.minDimension / 2
                        drawCircle(Color(0xFF0A0A0F), r)
                        var g = r * 0.95f
                        while (g > r * 0.4f) { drawCircle(Color(0xFF1B1B26), g, style = androidx.compose.ui.graphics.drawscope.Stroke(1.5f)); g -= 7f }
                        drawCircle(Brush.sweepGradient(listOf(Purple, Cyan, Silver, Purple)), r * 0.32f)
                        drawCircle(Color.Black, r * 0.04f)
                    }
                    Canvas(Modifier.fillMaxSize()) {
                        val pivot = Offset(size.width + 6f, 4f)
                        androidx.compose.ui.graphics.drawscope.rotate(armAngle, pivot) {
                            drawLine(Brush.verticalGradient(listOf(Silver, Cyan)), pivot, Offset(pivot.x, pivot.y + size.height * 0.62f), 8f)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(tracks.getOrNull(cur)?.title ?: if (denied) "Allow music access to see your songs" else "Pick a song",
                    color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(tracks.getOrNull(cur)?.artist ?: "", color = Silver.copy(alpha = .7f), fontSize = 13.sp, maxLines = 1)
                Slider(progress, { v -> progress = v; player?.let { it.seekTo((it.duration * v).toInt()) } },
                    colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Cyan, inactiveTrackColor = Edge))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    GlassButton(if (shuffle) "Shuffle on" else "Shuffle") { shuffle = !shuffle }
                    GlassButton("Prev") { step(-1) }
                    Box(
                        Modifier.size(60.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Cyan)))
                            .clickable {
                                val p = player
                                if (p == null) step(1) else if (p.isPlaying) { p.pause(); playing = false } else { p.start(); playing = true }
                            },
                        contentAlignment = Alignment.Center
                    ) { Text(if (playing) "II" else "Play", color = Color.Black, fontSize = 14.sp) }
                    GlassButton("Next") { step(1) }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true,
                    placeholder = { Text("Search your library") }, shape = RoundedCornerShape(24.dp))
                val shown = tracks.withIndex().filter { it.value.title.contains(query, true) }
                LazyColumn(Modifier.weight(1f).padding(top = 6.dp)) {
                    itemsIndexed(shown) { _, iv ->
                        val sel = iv.index == cur
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(14.dp))
                                .background(if (sel) Purple.copy(alpha = .25f) else Color.Transparent)
                                .clickable { play(iv.index) }.padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(iv.value.title, color = if (sel) Color.White else Silver, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GlassButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(Glass).border(1.dp, Edge, RoundedCornerShape(50))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp)
    ) { Text(label, color = Color.White, fontSize = 13.sp) }
}
